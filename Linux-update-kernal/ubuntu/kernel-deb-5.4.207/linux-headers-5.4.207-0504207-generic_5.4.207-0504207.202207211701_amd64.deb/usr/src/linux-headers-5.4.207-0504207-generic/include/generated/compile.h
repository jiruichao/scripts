/* This file is auto generated, version 202207211701 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202207211701 SMP Thu Jul 21 21:16:21 UTC 2022"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)"
